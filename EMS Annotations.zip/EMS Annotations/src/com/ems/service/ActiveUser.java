package com.ems.service;

public class ActiveUser {

	public static String username="";
}
